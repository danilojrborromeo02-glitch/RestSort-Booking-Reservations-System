
package RestSort;

public class ADMIN {

    private final AccountManager accounts;
    private final AmmenityManagement amenities;
    private final ReservationManagement reservations;

    public ADMIN(DataManager data) {
        accounts = new AccountManager(data);
        amenities = new AmmenityManagement(data);
        reservations = new ReservationManagement(data);
    }

    public void menu() {
        while (true) {
            System.out.println("\n========== ADMIN MENU ==========");
            System.out.println("[1] Add Agent Account");
            System.out.println("[2] Account List");
            System.out.println("[3] Manage Agent Accounts");
            System.out.println("[4] Reservation Records");
            System.out.println("[5] Cancel Reservation");
            System.out.println("[6] Manage Amenities");
            System.out.println("[7] Logout");

            int choice = MAIN.number("Choose: ");

            switch (choice) {
                case 1:
                    accounts.addAgent();
                    break;
                case 2:
                    accounts.listAccounts();
                    break;
                case 3:
                    accounts.manageAgents();
                    break;
                case 4:
                    reservations.showReservations();
                    break;
                case 5:
                    reservations.cancelReservation();
                    break;
                case 6:
                    amenities.menu();
                    break;
                case 7:
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}
