
package RestSort;

import java.io.*;
import java.util.*;

public class DataManager {

    public static final String DIR = "RestSortData";
    public static final String ACCOUNTS = DIR + "/accounts.txt";
    public static final String CUSTOMERS = DIR + "/customers.txt";
    public static final String AMENITIES = DIR + "/amenities.txt";
    public static final String RESERVATIONS = DIR + "/reservations.txt";
    public static final String TRANSACTIONS = DIR + "/transactions.txt";

    public DataManager() {
        new File(DIR).mkdirs();

        createFile(ACCOUNTS, Arrays.asList(
            "admin|admin123|Administrator|ADMIN"
        ));

        createFile(CUSTOMERS, Collections.emptyList());

        createFile(AMENITIES, Arrays.asList(
            "Swimming Pool|500.0|true",
            "Function Hall|5000.0|true",
            "Conference Room|2500.0|true",
            "Cottage|1000.0|true"
        ));

        createFile(RESERVATIONS, Collections.emptyList());
        createFile(TRANSACTIONS, Collections.emptyList());
    }

    private void createFile(String path, List<String> defaults) {
        File file = new File(path);

        if (!file.exists()) {
            write(path, defaults);
        }
    }

    public List<String> read(String path) {
        List<String> lines = new ArrayList<>();

        try (BufferedReader br =
                 new BufferedReader(new FileReader(path))) {

            String line;

            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    lines.add(line);
                }
            }

        } catch (IOException e) {
            System.out.println("Unable to read file: " + path);
        }

        return lines;
    }

    public void write(String path, List<String> lines) {
        try {
            File parent = new File(path).getParentFile();

            if (parent != null) {
                parent.mkdirs();
            }

            try (BufferedWriter bw =
                     new BufferedWriter(new FileWriter(path))) {

                for (String line : lines) {
                    bw.write(line);
                    bw.newLine();
                }
            }

        } catch (IOException e) {
            System.out.println("Unable to save file: " + path);
        }
    }

    public void append(String path, String line) {
        try (BufferedWriter bw =
                 new BufferedWriter(new FileWriter(path, true))) {

            bw.write(line);
            bw.newLine();

        } catch (IOException e) {
            System.out.println("Unable to save record.");
        }
    }

    public String[] fields(String line) {
        return line.split("\\|", -1);
    }

    public String find(String path, String id) {
        for (String line : read(path)) {
            String[] p = fields(line);

            if (p.length > 0 && p[0].equalsIgnoreCase(id)) {
                return line;
            }
        }

        return null;
    }

    public void replace(String path, String id, String replacement) {
        List<String> lines = read(path);

        for (int i = 0; i < lines.size(); i++) {
            String[] p = fields(lines.get(i));

            if (p.length > 0 && p[0].equalsIgnoreCase(id)) {
                lines.set(i, replacement);
                write(path, lines);
                return;
            }
        }
    }

    public void delete(String path, String id) {
        List<String> lines = read(path);

        lines.removeIf(line -> {
            String[] p = fields(line);
            return p.length > 0 && p[0].equalsIgnoreCase(id);
        });

        write(path, lines);
    }

    public String nextId(String prefix, String path) {
        int highest = 0;

        for (String line : read(path)) {
            String[] p = fields(line);

            if (p.length > 0 && p[0].startsWith(prefix)) {
                try {
                    int n = Integer.parseInt(
                        p[0].substring(prefix.length())
                    );

                    highest = Math.max(highest, n);

                } catch (NumberFormatException ignored) {
                }
            }
        }

        return prefix + (highest + 1);
    }

    public static String clean(String value) {
        if (value == null) {
            return "";
        }

        return value.trim().replace("|", "/");
    }
}
