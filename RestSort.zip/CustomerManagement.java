
package RestSort;

public class CustomerManagement {

    private final DataManager data;

    public CustomerManagement(DataManager data) {
        this.data = data;
    }

    public void menu() {
        while (true) {
            System.out.println("\n--- CUSTOMER INFORMATION ---");
            System.out.println("[1] Add Customer");
            System.out.println("[2] Customer List");
            System.out.println("[3] Search Customer");
            System.out.println("[4] Edit Customer");
            System.out.println("[5] Back");

            int choice = MAIN.number("Choose: ");

            switch (choice) {
                case 1:
                    addCustomer();
                    break;
                case 2:
                    listCustomers();
                    break;
                case 3:
                    searchCustomer();
                    break;
                case 4:
                    editCustomer();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    public void addCustomer() {
        String name = DataManager.clean(
            MAIN.input("Customer name: ")
        );

        String contact = DataManager.clean(
            MAIN.input("Contact number: ")
        );

        String email = DataManager.clean(
            MAIN.input("Email address: ")
        );

        if (name.isEmpty() || contact.isEmpty()) {
            System.out.println("Name and contact are required.");
            return;
        }

        String id = data.nextId("C", DataManager.CUSTOMERS);

        data.append(
            DataManager.CUSTOMERS,
            id + "|" + name + "|" + contact + "|" + email
        );

        System.out.println("Customer saved successfully.");
        System.out.println("Customer ID: " + id);
    }

    public void listCustomers() {
        System.out.println("\n--- CUSTOMER LIST ---");

        if (data.read(DataManager.CUSTOMERS).isEmpty()) {
            System.out.println("No customer records yet.");
            return;
        }

        for (String line : data.read(DataManager.CUSTOMERS)) {
            String[] p = data.fields(line);

            if (p.length >= 4) {
                System.out.println(
                    "ID: " + p[0]
                    + " | Name: " + p[1]
                    + " | Contact: " + p[2]
                    + " | Email: " + p[3]
                );
            }
        }
    }

    public String searchCustomer() {
        String id = MAIN.input("Customer ID: ");

        String record = data.find(
            DataManager.CUSTOMERS, id
        );

        if (record == null) {
            System.out.println("Customer not found.");
            return null;
        }

        String[] p = data.fields(record);

        System.out.println("\nCustomer ID: " + p[0]);
        System.out.println("Name: " + p[1]);
        System.out.println("Contact: " + p[2]);
        System.out.println("Email: " + p[3]);

        return record;
    }

    public void editCustomer() {
        String id = MAIN.input("Customer ID to edit: ");

        String record = data.find(
            DataManager.CUSTOMERS, id
        );

        if (record == null) {
            System.out.println("Customer not found.");
            return;
        }

        String[] p = data.fields(record);

        String name = MAIN.input(
            "New name (blank to keep): "
        );

        String contact = MAIN.input(
            "New contact (blank to keep): "
        );

        String email = MAIN.input(
            "New email (blank to keep): "
        );

        if (name.isEmpty()) name = p[1];
        if (contact.isEmpty()) contact = p[2];
        if (email.isEmpty()) email = p[3];

        String updated = id + "|"
            + DataManager.clean(name) + "|"
            + DataManager.clean(contact) + "|"
            + DataManager.clean(email);

        data.replace(
            DataManager.CUSTOMERS, id, updated
        );

        System.out.println("Customer information updated.");
    }
}
