
package RestSort;

import java.time.LocalDate;
import java.time.MonthDay;
import java.time.format.DateTimeParseException;
import java.util.List;

public class TransactionManagement {

    private final DataManager data;
    private final String transactionFile = DataManager.TRANSACTIONS;

    public TransactionManagement(DataManager data) {
        this.data = data;
    }

    public void menu() {
        boolean running = true;

        while (running) {
            System.out.println("\n==================================");
            System.out.println("       TRANSACTIONS / BILLING");
            System.out.println("==================================");
            System.out.println("[1] Create Bill");
            System.out.println("[2] Process Payment");
            System.out.println("[3] Print Receipt");
            System.out.println("[4] View Transaction History");
            System.out.println("[5] Add Other Transaction");
            System.out.println("[6] Back");
            System.out.println("==================================");

            String choice = MAIN.sc.nextLine().trim();

            switch (choice) {
                case "1":
                    createBill();
                    break;
                case "2":
                    processPayment();
                    break;
                case "3":
                    printReceipt();
                    break;
                case "4":
                    viewTransactionHistory();
                    break;
                case "5":
                    addOtherTransaction();
                    break;
                case "6":
                    running = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private String input(String message) {
        System.out.print(message);
        return MAIN.sc.nextLine().trim();
    }

    private double readAmount(String message) {
        while (true) {
            String value = input(message);

            try {
                double amount = Double.parseDouble(value);

                if (amount < 0) {
                    System.out.println("Amount cannot be negative.");
                    continue;
                }

                return amount;

            } catch (NumberFormatException e) {
                System.out.println("Invalid amount. Please enter a number.");
            }
        }
    }

    private String money(double amount) {
        return String.format("PHP %.2f", amount);
    }

    private double parseAmount(String value) {
        try {
            return Double.parseDouble(value.trim());
        } catch (Exception e) {
            return 0.0;
        }
    }

    private String statusOf(String[] p) {
        return p.length > 7 ? p[7] : "UNPAID";
    }

    private double discountRate(String[] p) {
        if (p.length > 8) {
            return parseAmount(p[8]);
        }
        return 0.0;
    }

    private double originalTotal(String[] p) {
        return p.length > 4 ? parseAmount(p[4]) : 0.0;
    }

    private double paidAmount(String[] p) {
        return p.length > 5 ? parseAmount(p[5]) : 0.0;
    }

    private double finalTotal(String[] p) {
        return originalTotal(p) * (1.0 - discountRate(p));
    }

    private double balanceAmount(String[] p) {
        return Math.max(0.0, finalTotal(p) - paidAmount(p));
    }

    private void createBill() {
        System.out.println("\n========== CREATE BILL ==========");

        String reservationId = input("Enter Reservation ID: ");

        String reservation = data.find(
                DataManager.RESERVATIONS, reservationId);

        if (reservation == null) {
            System.out.println("Reservation not found.");
            return;
        }

        String[] r = data.fields(reservation);

        if (r.length < 8) {
            System.out.println("Invalid reservation record.");
            return;
        }

        if ("CANCELLED".equalsIgnoreCase(r[7])) {
            System.out.println("Cannot create a bill for a cancelled reservation.");
            return;
        }

        if (findByReservation(reservationId) != null) {
            System.out.println("A bill already exists for this reservation.");
            System.out.println("Use Process Payment to continue.");
            return;
        }

        String customer = r[2];
        String date = r[3];
        String description = r[4];
        double total = parseAmount(r[5]);

        if (total <= 0) {
            System.out.println("Reservation total is invalid.");
            return;
        }

        double rate = calculateDiscount(date, description);
        double discount = total * rate;
        double finalAmount = total - discount;

        String transactionId = data.nextId("TR", transactionFile);

        String record = transactionId + "|"
                + reservationId + "|"
                + DataManager.clean(customer) + "|"
                + DataManager.clean(description) + "|"
                + total + "|"
                + 0.0 + "|"
                + finalAmount + "|"
                + "UNPAID|"
                + rate;

        data.append(transactionFile, record);

        System.out.println("\nBill created successfully!");
        System.out.println("Transaction ID : " + transactionId);
        System.out.println("Reservation ID : " + reservationId);
        System.out.println("Customer       : " + customer);
        System.out.println("Original Total : " + money(total));
        System.out.println("Discount       : " + String.format("%.0f%%", rate * 100));
        System.out.println("Discount Amount: " + money(discount));
        System.out.println("Final Total    : " + money(finalAmount));
        System.out.println("Status         : UNPAID");
    }

    private double calculateDiscount(String date, String selectedAmenities) {
        double rate = 0.0;

        int selectedCount = 0;

        if (selectedAmenities != null && !selectedAmenities.trim().isEmpty()) {
            String[] selected = selectedAmenities.split(",");

            for (String item : selected) {
                if (!item.trim().isEmpty()) {
                    selectedCount++;
                }
            }
        }

        int activeCount = 0;

        List<String> amenityList = data.read(DataManager.AMENITIES);

        for (String line : amenityList) {
            String[] a = data.fields(line);

            if (a.length >= 3 && Boolean.parseBoolean(a[2])) {
                activeCount++;
            }
        }

        if (selectedCount > 1) {
            rate = 0.05;
        }

        if (activeCount > 0 && selectedCount >= activeCount) {
            rate = Math.max(rate, 0.30);
        }

        try {
            LocalDate reservationDate = LocalDate.parse(date);

            MonthDay monthDay = MonthDay.from(reservationDate);

            if (monthDay.equals(MonthDay.of(1, 1))
                    || monthDay.equals(MonthDay.of(2, 14))
                    || monthDay.equals(MonthDay.of(12, 25))
                    || monthDay.equals(MonthDay.of(12, 31))) {
                rate = Math.max(rate, 0.20);
            }

        } catch (DateTimeParseException ignored) {
        }

        return rate;
    }

    private void processPayment() {
        System.out.println("\n========== PROCESS PAYMENT ==========");

        String transactionId = input("Enter Transaction ID: ");

        String record = data.find(transactionFile, transactionId);

        if (record == null) {
            System.out.println("Transaction not found.");
            return;
        }

        String[] p = data.fields(record);

        if (p.length < 9) {
            System.out.println("Invalid transaction record.");
            return;
        }

        double total = finalTotal(p);
        double paid = paidAmount(p);
        double balance = Math.max(0.0, total - paid);

        if (balance <= 0) {
            System.out.println("This bill is already fully paid.");
            return;
        }

        System.out.println("\nCustomer    : " + p[2]);
        System.out.println("Final Total : " + money(total));
        System.out.println("Paid        : " + money(paid));
        System.out.println("Balance     : " + money(balance));

        String method = input("Payment Method (Cash/GCash/Card): ");

        if (method.isEmpty()) {
            System.out.println("Payment method is required.");
            return;
        }

        double payment = readAmount("Enter Payment Amount: ");

        if (payment <= 0) {
            System.out.println("Payment must be greater than zero.");
            return;
        }

        if (payment > balance) {
            System.out.println("Payment cannot exceed the remaining balance.");
            return;
        }

        paid += payment;
        balance = Math.max(0.0, total - paid);

        p[5] = String.valueOf(paid);
        p[6] = String.valueOf(balance);
        p[7] = balance <= 0 ? "PAID" : "PARTIAL";

        data.replace(
                transactionFile,
                p[0],
                String.join("|", p)
        );

        System.out.println("\nPayment processed successfully!");
        System.out.println("Transaction ID : " + p[0]);
        System.out.println("Payment Method : " + method);
        System.out.println("Payment Amount : " + money(payment));
        System.out.println("Total Paid     : " + money(paid));
        System.out.println("Remaining      : " + money(balance));
        System.out.println("Status         : " + p[7]);
    }

    private void printReceipt() {
        System.out.println("\n========== PRINT RECEIPT ==========");

        String transactionId = input("Enter Transaction ID: ");

        String record = data.find(transactionFile, transactionId);

        if (record == null) {
            System.out.println("Transaction not found.");
            return;
        }

        String[] p = data.fields(record);

        if (p.length < 8) {
            System.out.println("Invalid transaction record.");
            return;
        }

        double original = originalTotal(p);
        double rate = discountRate(p);
        double discount = original * rate;
        double total = original - discount;
        double paid = paidAmount(p);
        double balance = Math.max(0.0, total - paid);

        System.out.println("\n==========================================");
        System.out.println("             RESTSORT RESORT");
        System.out.println("                  RECEIPT");
        System.out.println("==========================================");
        System.out.println("Transaction ID : " + p[0]);
        System.out.println("Reservation ID : " + p[1]);
        System.out.println("Customer       : " + p[2]);
        System.out.println("Description    : " + p[3]);
        System.out.println("------------------------------------------");
        System.out.println("Original Total : " + money(original));
        System.out.println("Discount Rate  : " + String.format("%.0f%%", rate * 100));
        System.out.println("Discount Amount: " + money(discount));
        System.out.println("------------------------------------------");
        System.out.println("Final Total    : " + money(total));
        System.out.println("Amount Paid    : " + money(paid));
        System.out.println("Balance        : " + money(balance));
        System.out.println("Payment Status : " + statusOf(p));
        System.out.println("==========================================");
        System.out.println("       Thank you for choosing us!");
        System.out.println("==========================================");
    }

    private void viewTransactionHistory() {
        System.out.println("\n========== TRANSACTION HISTORY ==========");

        List<String> list = data.read(transactionFile);

        if (list.isEmpty()) {
            System.out.println("No transactions found.");
            return;
        }

        System.out.printf(
                "%-10s %-12s %-18s %-14s %-14s %-12s%n",
                "ID", "Reservation", "Customer", "Total", "Balance", "Status");

        System.out.println("----------------------------------------------------------------------------");

        for (String line : list) {
            String[] p = data.fields(line);

            if (p.length >= 8) {
                double total = p.length > 8
                        ? originalTotal(p) * (1.0 - discountRate(p))
                        : originalTotal(p);

                double balance = Math.max(0.0, total - paidAmount(p));

                System.out.printf(
                        "%-10s %-12s %-18s %-14s %-14s %-12s%n",
                        p[0],
                        p[1],
                        shorten(p[2], 17),
                        String.format("%.2f", total),
                        String.format("%.2f", balance),
                        statusOf(p)
                );
            }
        }
    }

    private void addOtherTransaction() {
        System.out.println("\n========== ADD OTHER TRANSACTION ==========");

        String customer = input("Customer Name: ");

        if (customer.isEmpty()) {
            System.out.println("Customer name is required.");
            return;
        }

        String description = input("Transaction Description: ");

        if (description.isEmpty()) {
            System.out.println("Description is required.");
            return;
        }

        double amount = readAmount("Enter Amount: ");

        if (amount <= 0) {
            System.out.println("Amount must be greater than zero.");
            return;
        }

        String transactionId = data.nextId("TR", transactionFile);

        String record = transactionId + "|"
                + "OTHER|"
                + DataManager.clean(customer) + "|"
                + DataManager.clean(description) + "|"
                + amount + "|"
                + 0.0 + "|"
                + amount + "|"
                + "UNPAID|"
                + 0.0;

        data.append(transactionFile, record);

        System.out.println("Other transaction added successfully.");
        System.out.println("Transaction ID: " + transactionId);
        System.out.println("Amount: " + money(amount));
    }

    private String findByReservation(String reservationId) {
        List<String> list = data.read(transactionFile);

        for (String line : list) {
            String[] p = data.fields(line);

            if (p.length > 1
                    && p[1].equalsIgnoreCase(reservationId)) {
                return line;
            }
        }

        return null;
    }

    private String shorten(String value, int maxLength) {
        if (value == null) {
            return "";
        }

        if (value.length() <= maxLength) {
            return value;
        }

        return value.substring(0, maxLength - 3) + "...";
    }
}
