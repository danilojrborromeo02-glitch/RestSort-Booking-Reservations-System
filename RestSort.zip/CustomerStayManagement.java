
package RestSort;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Scanner;

public class CustomerStayManagement {

    private final String fileName =
            "C:\\Users\\Ailyn\\eclipse-workspace\\RESTSORT\\src\\RestSort\\customer_stays";

    private final DataManager data = new DataManager();
    private final ReservationManagement reservations =
            new ReservationManagement();

    private final DateTimeFormatter formatter =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");


    public void timeIn(Scanner sc) {

        System.out.println("\n========== CUSTOMER TIME IN ==========");

        reservations.showReservations();

        System.out.print("\nEnter Reservation ID: ");
        String id = sc.nextLine().trim();

        if (id.isEmpty()) {
            System.out.println("Reservation ID is required.");
            return;
        }

        String[] reservation = reservations.getActiveReservationById(id);

        if (reservation == null || reservation.length < 7) {
            System.out.println("Active reservation not found.");
            return;
        }

        String status = reservation[6].trim();

        if (!status.equalsIgnoreCase("CONFIRMED")) {
            System.out.println("TIME IN DENIED.");
            System.out.println("Reservation must be fully paid and confirmed.");
            System.out.println("Current status: " + status);
            return;
        }

        String reservationDate = reservation[2].trim();

        try {
            LocalDate bookingDate = LocalDate.parse(reservationDate);

            if (!bookingDate.equals(LocalDate.now())) {
                System.out.println("TIME IN DENIED.");
                System.out.println("Reservation date: " + bookingDate);
                System.out.println("Today's date: " + LocalDate.now());
                System.out.println(
                        "Customer can only check in on the reservation date.");
                return;
            }

        } catch (DateTimeParseException e) {
            System.out.println("Invalid reservation date.");
            return;
        }

        ArrayList<String> records = data.readLines(fileName);

        for (String record : records) {
            String[] r = record.split(",", -1);

            if (r.length >= 6
                    && r[0].trim().equalsIgnoreCase(id)) {

                if (!r[3].trim().isEmpty()) {
                    System.out.println("Customer has already checked in.");
                    System.out.println("Time In: " + r[3]);
                    return;
                }
            }
        }

        String timeIn = LocalDateTime.now().format(formatter);

        String record = id + ","
                + clean(reservation[1]) + ","
                + reservationDate + ","
                + timeIn + ","
                + ","
                + "CHECKED IN";

        if (data.appendLine(fileName, record)) {
            System.out.println("\nCustomer checked in successfully.");
            System.out.println("Reservation ID: " + id);
            System.out.println("Customer: " + reservation[1]);
            System.out.println("Time In: " + timeIn);
            System.out.println("Stay Status: CHECKED IN");
        } else {
            System.out.println("Unable to save Time In record.");
        }
    }

    public void timeOut(Scanner sc) {

        System.out.println("\n========== CUSTOMER TIME OUT ==========");

        showStayRecords();

        System.out.print("\nEnter Reservation ID: ");
        String id = sc.nextLine().trim();

        if (id.isEmpty()) {
            System.out.println("Reservation ID is required.");
            return;
        }

        ArrayList<String> records = data.readLines(fileName);
        ArrayList<String> updated = new ArrayList<>();

        boolean found = false;
        boolean completed = false;

        for (String record : records) {

            String[] r = record.split(",", -1);

            if (r.length >= 6
                    && r[0].trim().equalsIgnoreCase(id)) {

                found = true;

                if (r[3].trim().isEmpty()) {
                    System.out.println(
                            "Cannot check out. Customer has not checked in.");
                    return;
                }

                if (!r[4].trim().isEmpty()
                        || r[5].trim().equalsIgnoreCase("COMPLETED")) {
                    System.out.println("Customer has already checked out.");
                    return;
                }

                r[4] = LocalDateTime.now().format(formatter);
                r[5] = "COMPLETED";

                updated.add(String.join(",", r));
                completed = true;

            } else {
                updated.add(record);
            }
        }

        if (!found) {
            System.out.println("Stay record not found.");
            System.out.println("Customer must check in first.");
            return;
        }

        if (completed && data.writeLines(fileName, updated)) {
            System.out.println("\nCustomer checked out successfully.");
            System.out.println("Reservation ID: " + id);
            System.out.println("Time Out: " +
                    findTimeOut(updated, id));
            System.out.println("Stay Status: COMPLETED");
        } else {
            System.out.println("Unable to save Time Out record.");
        }
    }

    public void showStayRecords() {

        ArrayList<String> records = data.readLines(fileName);

        System.out.println("\n========== CUSTOMER STAY RECORDS ==========");

        if (records.isEmpty()) {
            System.out.println("No stay records found.");
            return;
        }

        System.out.printf(
                "%-12s %-22s %-12s %-20s %-20s %-12s%n",
                "RESERVATION", "CUSTOMER", "DATE",
                "TIME IN", "TIME OUT", "STATUS");

        for (String record : records) {

            String[] r = record.split(",", -1);

            if (r.length >= 6) {
                System.out.printf(
                        "%-12s %-22s %-12s %-20s %-20s %-12s%n",
                        r[0], r[1], r[2], r[3],
                        r[4].isEmpty() ? "N/A" : r[4],
                        r[5]);
            }
        }
    }

    private String findTimeOut(
            ArrayList<String> records, String id) {

        for (String record : records) {
            String[] r = record.split(",", -1);

            if (r.length >= 6
                    && r[0].trim().equalsIgnoreCase(id)) {
                return r[4];
            }
        }

        return "";
    }

    private String clean(String value) {
        if (value == null) {
            return "";
        }

        return value.replace(",", " ")
                .replace("\n", " ")
                .replace("\r", " ")
                .trim();
    }
}
