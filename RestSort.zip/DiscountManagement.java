
package RestSort;

import java.time.LocalDate;
import java.util.*;

public class DiscountManagement {

    private final DataManager data;

    public DiscountManagement(DataManager data) {
        this.data = data;
    }

    public void menu() {
        while (true) {
            System.out.println("\n--- DISCOUNT MANAGEMENT ---");
            System.out.println("[1] View Discount Rules");
            System.out.println("[2] Calculate Reservation Discount");
            System.out.println("[3] Check Holiday Reservation");
            System.out.println("[4] Back");

            int choice = MAIN.number("Choose: ");

            switch (choice) {
                case 1:
                    showRules();
                    break;
                case 2:
                    calculateReservationDiscount();
                    break;
                case 3:
                    checkHolidayReservation();
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    public void showRules() {
        System.out.println("\n--- DISCOUNT RULES ---");
        System.out.println("Holiday Reservation: 20%");
        System.out.println("Multiple Amenities: 5%");
        System.out.println("All Active Amenities: 30%");
        System.out.println("Only the highest applicable discount is applied.");
        System.out.println("\nNote: Holiday checking uses the dates listed in this class.");
    }

    public double getDiscountRate(String reservationId) {
        String record = data.find(
            DataManager.RESERVATIONS, reservationId
        );

        if (record == null) {
            return 0;
        }

        String[] p = data.fields(record);

        if (p.length < 8 ||
                !p[7].equalsIgnoreCase("BOOKED")) {
            return 0;
        }

        double rate = 0;

        try {
            LocalDate date = LocalDate.parse(p[3]);

            if (isHoliday(date)) {
                rate = Math.max(rate, 0.20);
            }
        } catch (Exception e) {
            System.out.println("Unable to check reservation date.");
        }

        String[] selected = p[4].split(",");
        int activeCount = 0;

        for (String line : data.read(DataManager.AMENITIES)) {
            String[] a = data.fields(line);

            if (a.length >= 3 &&
                    Boolean.parseBoolean(a[2])) {
                activeCount++;
            }
        }

        if (selected.length > 1) {
            rate = Math.max(rate, 0.05);
        }

        Set<String> selectedNames = new HashSet<>();

        for (String name : selected) {
            selectedNames.add(name.trim().toLowerCase(Locale.ROOT));
        }

        int selectedActiveCount = 0;

        for (String line : data.read(DataManager.AMENITIES)) {
            String[] a = data.fields(line);

            if (a.length >= 3 &&
                    Boolean.parseBoolean(a[2]) &&
                    selectedNames.contains(a[0].trim().toLowerCase(Locale.ROOT))) {
                selectedActiveCount++;
            }
        }

        if (activeCount > 0 && selectedActiveCount >= activeCount) {
            rate = Math.max(rate, 0.30);
        }

        return rate;
    }

    public double discountedTotal(String reservationId) {
        String record = data.find(
            DataManager.RESERVATIONS, reservationId
        );

        if (record == null) {
            return 0;
        }

        String[] p = data.fields(record);

        if (p.length < 8 ||
                !p[7].equalsIgnoreCase("BOOKED")) {
            return 0;
        }

        try {
            double total = Double.parseDouble(p[5]);
            return total * (1 - getDiscountRate(reservationId));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private boolean isHoliday(LocalDate date) {
        int month = date.getMonthValue();
        int day = date.getDayOfMonth();

        return (month == 1 && day == 1)
            || (month == 4 && day == 9)
            || (month == 5 && day == 1)
            || (month == 6 && day == 12)
            || (month == 8 && day == 21)
            || (month == 8 && date.getDayOfWeek().getValue() == 1
                && day >= 29)
            || (month == 11 && day == 30)
            || (month == 12 && day == 25)
            || (month == 12 && day == 30);
    }

    private void checkHolidayReservation() {
        String id = MAIN.input("Reservation ID: ");

        String record = data.find(
            DataManager.RESERVATIONS, id
        );

        if (record == null) {
            System.out.println("Reservation not found.");
            return;
        }

        String[] p = data.fields(record);

        if (p.length < 8 ||
                !p[7].equalsIgnoreCase("BOOKED")) {
            System.out.println("Active reservation not found.");
            return;
        }

        try {
            LocalDate date = LocalDate.parse(p[3]);

            System.out.println("\n--- HOLIDAY CHECK ---");
            System.out.println("Reservation ID: " + p[0]);
            System.out.println("Customer: " + p[2]);
            System.out.println("Reservation Date: " + date);

            if (isHoliday(date)) {
                System.out.println("Holiday Status: HOLIDAY");
                System.out.println("Holiday Discount Condition: 20%");
            } else {
                System.out.println("Holiday Status: Not in the configured holiday list");
                System.out.println("Holiday Discount Condition: Not applied");
            }

            double rate = getDiscountRate(id);
            double original = Double.parseDouble(p[5]);
            double discount = original * rate;

            System.out.printf(
                Locale.US,
                "Highest Applicable Discount: %.0f%%%n",
                rate * 100
            );

            System.out.printf(
                Locale.US,
                "Discount Amount: PHP %.2f%n",
                discount
            );

            System.out.printf(
                Locale.US,
                "Total After Discount: PHP %.2f%n",
                original - discount
            );

        } catch (Exception e) {
            System.out.println("Unable to calculate discount for this reservation.");
        }
    }

    private void calculateReservationDiscount() {
        String id = MAIN.input("Reservation ID: ");

        String record = data.find(
            DataManager.RESERVATIONS, id
        );

        if (record == null) {
            System.out.println("Reservation not found.");
            return;
        }

        String[] p = data.fields(record);

        if (p.length < 8 ||
                !p[7].equalsIgnoreCase("BOOKED")) {
            System.out.println("Active reservation not found.");
            return;
        }

        try {
            double original = Double.parseDouble(p[5]);
            double rate = getDiscountRate(id);
            double discount = original * rate;
            double finalTotal = original - discount;

            System.out.println("\n--- RESERVATION DISCOUNT ---");
            System.out.println("Reservation ID: " + p[0]);
            System.out.println("Reservation Date: " + p[3]);

            if (isHoliday(LocalDate.parse(p[3]))) {
                System.out.println("Holiday: Yes");
            } else {
                System.out.println("Holiday: Not in configured list");
            }

            System.out.printf(
                Locale.US, "Original Total: PHP %.2f%n", original
            );
            System.out.printf(
                Locale.US, "Discount Rate: %.0f%%%n", rate * 100
            );
            System.out.printf(
                Locale.US, "Discount Amount: PHP %.2f%n", discount
            );
            System.out.printf(
                Locale.US, "Total After Discount: PHP %.2f%n", finalTotal
            );

        } catch (Exception e) {
            System.out.println("Unable to calculate discount.");
        }
    }
}
