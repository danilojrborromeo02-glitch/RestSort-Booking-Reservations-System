
package RestSort;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class ReservationManagement {

    private final DataManager data;
    private final AmmenityManagement amenities;

    public ReservationManagement(DataManager data) {
        this.data = data;
        this.amenities = new AmmenityManagement(data);
    }

    public void createReservation(String agentName) {
        System.out.println("\n========================================");
        System.out.println("          CREATE RESERVATION");
        System.out.println("========================================");

        List<String> customers = data.read(DataManager.CUSTOMERS);

        if (customers.isEmpty()) {
            System.out.println("No customers registered yet.");
            System.out.println("Please add a customer under Customer Information first.");
            return;
        }

        System.out.println("\n--- CUSTOMER LIST ---");
        for (String line : customers) {
            String[] c = data.fields(line);

            if (c.length >= 4) {
                System.out.println(
                    c[0] + " | " + c[1] +
                    " | Contact: " + c[2]
                );
            }
        }

        String customerId;
        String[] customer;

        while (true) {
            customerId = MAIN.input("\nEnter Customer ID: ");
            String record = data.find(DataManager.CUSTOMERS, customerId);

            if (record == null) {
                System.out.println("Customer ID not found. Please try again.");
                continue;
            }

            customer = data.fields(record);

            if (customer.length < 4) {
                System.out.println("Customer record is incomplete.");
                return;
            }

            break;
        }

        System.out.println("\nCustomer Name: " + customer[1]);
        System.out.println("Contact      : " + customer[2]);
        System.out.println("Email        : " + customer[3]);

        String date;

        while (true) {
            date = MAIN.input("\nReservation Date (YYYY-MM-DD): ");

            try {
                LocalDate selectedDate = LocalDate.parse(date);

                if (selectedDate.isBefore(LocalDate.now())) {
                    System.out.println("Date cannot be in the past.");
                    continue;
                }

                if (hasActiveReservationOnDate(date)) {
                    System.out.println(
                        "This date already has an active reservation."
                    );
                    System.out.println("Please choose another date.");
                    continue;
                }

                break;

            } catch (DateTimeParseException e) {
                System.out.println("Invalid date format. Use YYYY-MM-DD.");
            }
        }

        List<String[]> available = getAvailableAmenities();

        if (available.isEmpty()) {
            System.out.println("No available amenities found.");
            return;
        }

        System.out.println("\n--- AVAILABLE AMENITIES ---");

        for (int i = 0; i < available.size(); i++) {
            String[] a = available.get(i);
            System.out.printf(
                Locale.US,
                "[%d] %s - PHP %.2f%n",
                i + 1,
                a[0],
                Double.parseDouble(a[1])
            );
        }

        System.out.println("\nYou may select multiple amenities.");
        System.out.println("Example: 1,2");

        List<Integer> selectedIndexes = new ArrayList<>();

        while (selectedIndexes.isEmpty()) {
            String selection = MAIN.input("Select Amenities: ");
            Set<Integer> indexes = new LinkedHashSet<>();
            boolean valid = true;

            for (String value : selection.split(",")) {
                try {
                    int number = Integer.parseInt(value.trim());

                    if (number < 1 || number > available.size()) {
                        valid = false;
                        break;
                    }

                    indexes.add(number - 1);

                } catch (NumberFormatException e) {
                    valid = false;
                    break;
                }
            }

            if (!valid || indexes.isEmpty()) {
                System.out.println(
                    "Invalid selection. Enter valid amenity numbers."
                );
            } else {
                selectedIndexes.addAll(indexes);
            }
        }

        List<String> selectedNames = new ArrayList<>();
        double total = 0.0;

        for (int index : selectedIndexes) {
            String[] amenity = available.get(index);

            selectedNames.add(amenity[0]);

            try {
                total += Double.parseDouble(amenity[1]);
            } catch (NumberFormatException e) {
                System.out.println("Invalid price for " + amenity[0]);
                return;
            }
        }

        System.out.println("\n========== RESERVATION SUMMARY ==========");
        System.out.println("Customer ID : " + customer[0]);
        System.out.println("Customer    : " + customer[1]);
        System.out.println("Contact     : " + customer[2]);
        System.out.println("Date        : " + date);
        System.out.println("Amenities   : " + String.join(", ", selectedNames));
        System.out.printf(Locale.US, "Total       : PHP %.2f%n", total);

        if (!MAIN.yes("Save this reservation?")) {
            System.out.println("Reservation was not saved.");
            return;
        }

        String id = data.nextId("RS", DataManager.RESERVATIONS);

        String record = id + "|"
            + DataManager.clean(customer[0]) + "|"
            + DataManager.clean(customer[1]) + "|"
            + date + "|"
            + DataManager.clean(String.join(",", selectedNames)) + "|"
            + String.format(Locale.US, "%.2f", total) + "|"
            + DataManager.clean(agentName) + "|BOOKED";

        data.append(DataManager.RESERVATIONS, record);

        System.out.println("\nReservation created successfully!");
        System.out.println("Reservation ID: " + id);
        System.out.println("Status: BOOKED");
        System.out.println("You may now go to Transactions / Billing to create a bill.");
    }

    private List<String[]> getAvailableAmenities() {
        List<String[]> result = new ArrayList<>();

        for (String line : data.read(DataManager.AMENITIES)) {
            String[] a = data.fields(line);

            if (a.length >= 3 && Boolean.parseBoolean(a[2])) {
                result.add(new String[] { a[0], a[1] });
            }
        }

        return result;
    }

    public boolean hasActiveReservationOnDate(String date) {
        for (String line : data.read(DataManager.RESERVATIONS)) {
            String[] p = data.fields(line);

            if (p.length >= 8
                    && p[3].equals(date)
                    && p[7].equalsIgnoreCase("BOOKED")) {
                return true;
            }
        }

        return false;
    }

    public void showReservations() {
        System.out.println("\n========== RESERVATIONS ==========");

        List<String> lines = data.read(DataManager.RESERVATIONS);

        if (lines.isEmpty()) {
            System.out.println("No reservations found.");
            return;
        }

        for (String line : lines) {
            String[] p = data.fields(line);

            if (p.length >= 8) {
                System.out.println("----------------------------------------");
                System.out.println("Reservation ID: " + p[0]);
                System.out.println("Customer ID   : " + p[1]);
                System.out.println("Customer      : " + p[2]);
                System.out.println("Date          : " + p[3]);
                System.out.println("Amenities     : " + p[4]);
                System.out.println("Total         : PHP " + p[5]);
                System.out.println("Agent         : " + p[6]);
                System.out.println("Status        : " + p[7]);
            }
        }
    }

    public void cancelReservation() {
        System.out.println("\n========== CANCEL RESERVATION ==========");

        String id = MAIN.input("Reservation ID: ");
        String record = data.find(DataManager.RESERVATIONS, id);

        if (record == null) {
            System.out.println("Reservation not found.");
            return;
        }

        String[] p = data.fields(record);

        if (p.length < 8 || !p[7].equalsIgnoreCase("BOOKED")) {
            System.out.println("This reservation is not active.");
            return;
        }

        if (!MAIN.yes("Are you sure you want to cancel this reservation?")) {
            System.out.println("Cancellation stopped.");
            return;
        }

        p[7] = "CANCELLED";

        data.replace(
            DataManager.RESERVATIONS,
            id,
            String.join("|", p)
        );

        System.out.println("Reservation cancelled successfully.");
    }

    public void manageReservation() {
        System.out.println("\n========== MANAGE RESERVATION ==========");

        String id = MAIN.input("Reservation ID: ");
        String record = data.find(DataManager.RESERVATIONS, id);

        if (record == null) {
            System.out.println("Reservation not found.");
            return;
        }

        String[] p = data.fields(record);

        if (p.length < 8 || !p[7].equalsIgnoreCase("BOOKED")) {
            System.out.println("Active reservation not found.");
            return;
        }

        while (true) {
            System.out.println("\nReservation ID: " + p[0]);
            System.out.println("Customer      : " + p[2]);
            System.out.println("Date          : " + p[3]);
            System.out.println("Amenities     : " + p[4]);
            System.out.println("Total         : PHP " + p[5]);
            System.out.println("[1] Change Reservation Date");
            System.out.println("[2] Add Amenity");
            System.out.println("[3] Remove Amenity");
            System.out.println("[4] Back");

            int choice = MAIN.number("Choose: ");

            switch (choice) {
                case 1:
                    changeDate(p);
                    break;
                case 2:
                    addAmenity(p);
                    break;
                case 3:
                    removeAmenity(p);
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice.");
                    continue;
            }

            data.replace(
                DataManager.RESERVATIONS,
                id,
                String.join("|", p)
            );
        }
    }

    private void changeDate(String[] p) {
        String date = MAIN.input("New Date (YYYY-MM-DD): ");

        try {
            LocalDate selectedDate = LocalDate.parse(date);

            if (selectedDate.isBefore(LocalDate.now())) {
                System.out.println("Date cannot be in the past.");
                return;
            }
        } catch (DateTimeParseException e) {
            System.out.println("Invalid date format.");
            return;
        }

        if (!date.equals(p[3]) && hasActiveReservationOnDate(date)) {
            System.out.println("That date already has an active reservation.");
            return;
        }

        p[3] = date;
        System.out.println("Reservation date updated.");
    }

    private void addAmenity(String[] p) {
        List<String[]> available = getAvailableAmenities();
        List<String> current = new ArrayList<>(
            Arrays.asList(p[4].split(","))
        );

        List<String[]> choices = new ArrayList<>();

        for (String[] a : available) {
            boolean exists = false;

            for (String name : current) {
                if (name.trim().equalsIgnoreCase(a[0])) {
                    exists = true;
                    break;
                }
            }

            if (!exists) {
                choices.add(a);
            }
        }

        if (choices.isEmpty()) {
            System.out.println("No additional amenities available.");
            return;
        }

        for (int i = 0; i < choices.size(); i++) {
            System.out.println(
                "[" + (i + 1) + "] " + choices.get(i)[0]
                + " - PHP " + choices.get(i)[1]
            );
        }

        int choice = MAIN.number("Choose amenity: ");

        if (choice < 1 || choice > choices.size()) {
            System.out.println("Invalid choice.");
            return;
        }

        String[] selected = choices.get(choice - 1);
        current.add(selected[0]);

        p[4] = String.join(",", current);
        p[5] = String.format(Locale.US, "%.2f", calculateTotal(current));

        System.out.println("Amenity added successfully.");
        System.out.println("Updated total: PHP " + p[5]);
    }

    private void removeAmenity(String[] p) {
        List<String> current = new ArrayList<>(
            Arrays.asList(p[4].split(","))
        );

        if (current.size() <= 1) {
            System.out.println("At least one amenity must remain.");
            return;
        }

        for (int i = 0; i < current.size(); i++) {
            System.out.println("[" + (i + 1) + "] " + current.get(i));
        }

        int choice = MAIN.number("Choose amenity to remove: ");

        if (choice < 1 || choice > current.size()) {
            System.out.println("Invalid choice.");
            return;
        }

        current.remove(choice - 1);

        p[4] = String.join(",", current);
        p[5] = String.format(Locale.US, "%.2f", calculateTotal(current));

        System.out.println("Amenity removed successfully.");
        System.out.println("Updated total: PHP " + p[5]);
    }

    private double calculateTotal(List<String> names) {
        double total = 0.0;

        for (String name : names) {
            for (String line : data.read(DataManager.AMENITIES)) {
                String[] a = data.fields(line);

                if (a.length >= 2 && a[0].equalsIgnoreCase(name.trim())) {
                    try {
                        total += Double.parseDouble(a[1]);
                    } catch (NumberFormatException ignored) {
                    }

                    break;
                }
            }
        }

        return total;
    }
}
