
package RestSort;

public class AccountManager {

    private final DataManager data;

    public AccountManager(DataManager data) {
        this.data = data;
    }

    public String[] login(String role) {

        String[] account = null;

        while (account == null) {
            System.out.println("\n=== " + role + " LOGIN ===");

            String username = MAIN.input("Username: ");

            for (String line : data.read(DataManager.ACCOUNTS)) {
                String[] parts = line.split("\\|", -1);

                if (parts.length >= 4
                        && parts[0].equals(username)
                        && parts[3].equalsIgnoreCase(role)) {
                    account = parts;
                    break;
                }
            }

            if (account == null) {
                System.out.println("Username not found. Please try again.");
            }
        }

        while (true) {
            String password = MAIN.input("Password: ");

            if (account[1].equals(password)) {
                System.out.println("Login successful!");
                return account;
            }

            System.out.println(
                "Incorrect password. Please enter your password again."
            );
        }
    }

    public void addAgent() {
        System.out.println("\n=== ADD AGENT ACCOUNT ===");

        String username;

        while (true) {
            username = MAIN.input("Username: ");

            if (username.isEmpty()) {
                System.out.println("Username cannot be empty.");
                continue;
            }

            if (data.find(DataManager.ACCOUNTS, username) != null) {
                System.out.println("Username already exists.");
                continue;
            }

            break;
        }

        String password;

        while (true) {
            password = MAIN.input("Password: ");

            if (password.isEmpty()) {
                System.out.println("Password cannot be empty.");
            } else {
                break;
            }
        }

        String name;

        while (true) {
            name = MAIN.input("Agent Name: ");

            if (name.isEmpty()) {
                System.out.println("Agent name cannot be empty.");
            } else {
                break;
            }
        }

        String record = data.clean(username) + "|"
                + data.clean(password) + "|"
                + data.clean(name) + "|AGENT";

        data.append(DataManager.ACCOUNTS, record);

        System.out.println("Agent account created successfully!");
    }

    public void listAccounts() {
        System.out.println("\n=== ACCOUNT LIST ===");

        boolean found = false;

        for (String line : data.read(DataManager.ACCOUNTS)) {
            String[] parts = line.split("\\|", -1);

            if (parts.length >= 4) {
                System.out.println("--------------------------------");
                System.out.println("Username: " + parts[0]);
                System.out.println("Name: " + parts[2]);
                System.out.println("Role: " + parts[3]);

                found = true;
            }
        }

        if (!found) {
            System.out.println("No accounts found.");
        }
    }

    public void manageAgents() {
        while (true) {
            System.out.println("\n=== MANAGE AGENT ACCOUNTS ===");
            System.out.println("[1] Edit Agent Account");
            System.out.println("[2] Delete Agent Account");
            System.out.println("[3] Back");

            int choice = MAIN.number("Choose: ");

            switch (choice) {
                case 1:
                    editAgent();
                    break;

                case 2:
                    deleteAgent();
                    break;

                case 3:
                    return;

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private void editAgent() {
        System.out.println("\n=== EDIT AGENT ACCOUNT ===");

        String username = MAIN.input("Enter agent username: ");
        String line = data.find(DataManager.ACCOUNTS, username);

        if (line == null) {
            System.out.println("Account not found.");
            return;
        }

        String[] parts = line.split("\\|", -1);

        if (parts.length < 4
                || !parts[3].equalsIgnoreCase("AGENT")) {
            System.out.println("Only Agent accounts can be edited here.");
            return;
        }

        System.out.println("Leave blank to keep the current value.");

        String newUsername = MAIN.input("New Username: ");
        String newPassword = MAIN.input("New Password: ");
        String newName = MAIN.input("New Agent Name: ");

        if (!newUsername.isEmpty()
                && !newUsername.equals(parts[0])
                && data.find(DataManager.ACCOUNTS, newUsername) != null) {
            System.out.println("Username already exists.");
            return;
        }

        if (!newUsername.isEmpty()) {
            parts[0] = data.clean(newUsername);
        }

        if (!newPassword.isEmpty()) {
            parts[1] = data.clean(newPassword);
        }

        if (!newName.isEmpty()) {
            parts[2] = data.clean(newName);
        }

        data.replace(
            DataManager.ACCOUNTS,
            username,
            String.join("|", parts)
        );

        System.out.println("Agent account updated successfully!");
    }

    private void deleteAgent() {
        System.out.println("\n=== DELETE AGENT ACCOUNT ===");

        String username = MAIN.input("Enter agent username: ");
        String line = data.find(DataManager.ACCOUNTS, username);

        if (line == null) {
            System.out.println("Account not found.");
            return;
        }

        String[] parts = line.split("\\|", -1);

        if (parts.length < 4
                || !parts[3].equalsIgnoreCase("AGENT")) {
            System.out.println("Only Agent accounts can be deleted here.");
            return;
        }

        if (MAIN.yes("Are you sure you want to delete this account?")) {
            data.delete(DataManager.ACCOUNTS, username);
            System.out.println("Agent account deleted successfully!");
        } else {
            System.out.println("Deletion cancelled.");
        }
    }
}
