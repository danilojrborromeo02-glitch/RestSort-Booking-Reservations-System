
package RestSort;

import java.util.ArrayList;

public class AmmenityManagement {

    private final DataManager data;

    public AmmenityManagement(DataManager data) {
        this.data = data;
    }

    public void menu() {
        while (true) {
            System.out.println("\n================================");
            System.out.println("       AMENITY MANAGEMENT");
            System.out.println("================================");
            System.out.println("[1] View All Amenities");
            System.out.println("[2] Add New Amenity");
            System.out.println("[3] Edit Amenity");
            System.out.println("[4] Remove Amenity");
            System.out.println("[5] Change Availability");
            System.out.println("[6] Back");

            int choice = MAIN.number("Choose: ");

            switch (choice) {
                case 1:
                    showAmenities();
                    break;
                case 2:
                    addAmenity();
                    break;
                case 3:
                    editAmenity();
                    break;
                case 4:
                    removeAmenity();
                    break;
                case 5:
                    changeAvailability();
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    public void showAmenities() {
        System.out.println("\n================ AMENITIES ================");

        ArrayList<String> list = (ArrayList<String>) data.read(DataManager.AMENITIES);

        if (list.isEmpty()) {
            System.out.println("No amenities found.");
            return;
        }

        System.out.printf("%-25s %-12s %-15s%n",
                "Amenity", "Price", "Availability");
        System.out.println("------------------------------------------------------");

        for (String line : list) {
            String[] parts = line.split("\\|", -1);

            if (parts.length >= 3) {
                String status = Boolean.parseBoolean(parts[2])
                        ? "AVAILABLE" : "UNAVAILABLE";

                System.out.printf("%-25s ₱%-11s %-15s%n",
                        parts[0], parts[1], status);
            }
        }
    }

    public void addAmenity() {
        System.out.println("\n=== ADD NEW AMENITY ===");

        String name;

        while (true) {
            name = MAIN.input("Amenity Name: ");

            if (name.isEmpty()) {
                System.out.println("Name cannot be empty.");
                continue;
            }

            if (findAmenity(name) != null) {
                System.out.println("Amenity already exists.");
                continue;
            }

            break;
        }

        double price = MAIN.amount("Price: ");

        String record = data.clean(name) + "|" + price + "|true";
        data.append(DataManager.AMENITIES, record);

        System.out.println("Amenity added successfully!");
        System.out.println("It is now available for customer reservations.");
    }

    private void editAmenity() {
        showAmenities();

        String name = MAIN.input("\nEnter amenity name to edit: ");
        String line = findAmenity(name);

        if (line == null) {
            System.out.println("Amenity not found.");
            return;
        }

        String[] parts = line.split("\\|", -1);

        if (parts.length < 3) {
            System.out.println("Invalid amenity record.");
            return;
        }

        System.out.println("Leave a field blank to keep its current value.");

        String newName = MAIN.input("New Name: ");

        if (!newName.isEmpty()
                && !newName.equalsIgnoreCase(parts[0])
                && findAmenity(newName) != null) {
            System.out.println("That amenity name already exists.");
            return;
        }

        String newPrice = MAIN.input("New Price: ");

        if (!newName.isEmpty()) {
            parts[0] = data.clean(newName);
        }

        if (!newPrice.isEmpty()) {
            try {
                double price = Double.parseDouble(newPrice);

                if (price < 0) {
                    System.out.println("Price cannot be negative.");
                    return;
                }

                parts[1] = String.valueOf(price);

            } catch (NumberFormatException e) {
                System.out.println("Invalid price.");
                return;
            }
        }

        data.replace(
                DataManager.AMENITIES,
                name,
                String.join("|", parts)
        );

        System.out.println("Amenity updated successfully!");
    }

    private void removeAmenity() {
        showAmenities();

        String name = MAIN.input("\nEnter amenity name to remove: ");
        String line = findAmenity(name);

        if (line == null) {
            System.out.println("Amenity not found.");
            return;
        }

        if (MAIN.yes("Remove " + name + "?")) {
            data.delete(DataManager.AMENITIES, name);
            System.out.println("Amenity removed successfully!");
        } else {
            System.out.println("Removal cancelled.");
        }
    }

    private void changeAvailability() {
        showAmenities();

        String name = MAIN.input("\nEnter amenity name: ");
        String line = findAmenity(name);

        if (line == null) {
            System.out.println("Amenity not found.");
            return;
        }

        String[] parts = line.split("\\|", -1);

        if (parts.length < 3) {
            System.out.println("Invalid amenity record.");
            return;
        }

        boolean available = Boolean.parseBoolean(parts[2]);
        parts[2] = String.valueOf(!available);

        data.replace(
                DataManager.AMENITIES,
                name,
                String.join("|", parts)
        );

        System.out.println(parts[0] + " is now "
                + (Boolean.parseBoolean(parts[2])
                ? "AVAILABLE." : "UNAVAILABLE."));
    }

    private String findAmenity(String name) {
        for (String line : data.read(DataManager.AMENITIES)) {
            String[] parts = line.split("\\|", -1);

            if (parts.length >= 3
                    && parts[0].equalsIgnoreCase(name)) {
                return line;
            }
        }

        return null;
    }

    public ArrayList<String[]> availableAmenities() {
        ArrayList<String[]> available = new ArrayList<>();

        for (String line : data.read(DataManager.AMENITIES)) {
            String[] parts = line.split("\\|", -1);

            if (parts.length >= 3
                    && Boolean.parseBoolean(parts[2])) {
                available.add(parts);
            }
        }

        return available;
    }

    public ArrayList<String[]> getAmenities() {
        ArrayList<String[]> amenities = new ArrayList<>();

        for (String line : data.read(DataManager.AMENITIES)) {
            String[] parts = line.split("\\|", -1);

            if (parts.length >= 3) {
                amenities.add(parts);
            }
        }

        return amenities;
    }
}
