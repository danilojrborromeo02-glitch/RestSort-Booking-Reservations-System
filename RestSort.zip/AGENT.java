
package RestSort;

public class AGENT {

    private final DataManager data;
    private final String agentName;

    private final ReservationManagement reservations;
    private final AmmenityManagement amenities;
    private final CustomerManagement customers;
    private final TransactionManagement transactions;
    private final DiscountManagement discounts;

    public AGENT(DataManager data, String agentName) {
        this.data = data;
        this.agentName = agentName;

        reservations = new ReservationManagement(data);
        amenities = new AmmenityManagement(data);
        customers = new CustomerManagement(data);
        discounts = new DiscountManagement(data);
        transactions = new TransactionManagement(data);
    }

    public void menu() {
        while (true) {
            System.out.println("\n========================================");
            System.out.println("           RESTSORT RESORT");
            System.out.println("             AGENT DASHBOARD");
            System.out.println("========================================");
            System.out.println("Welcome, " + agentName + "!");
            System.out.println("----------------------------------------");
            System.out.println("[1] Customer Information");
            System.out.println("[2] View / Manage Amenities");
            System.out.println("[3] Create Reservation");
            System.out.println("[4] View Reservations");
            System.out.println("[5] Cancel Reservation");
            System.out.println("[6] Transactions / Billing");
            System.out.println("[7] Discount Management");
            System.out.println("[8] Logout");
            System.out.println("[9] Manage Reservation");
            System.out.println("========================================");

            int choice = MAIN.number("Choose: ");

            switch (choice) {
                case 1:
                    customers.menu();
                    break;

                case 2:
                    amenities.menu();
                    break;

                case 3:
                    reservations.createReservation(agentName);
                    break;

                case 4:
                    reservations.showReservations();
                    break;

                case 5:
                    reservations.cancelReservation();
                    break;

                case 6:
                    transactions.menu();
                    break;

                case 7:
                    discounts.menu();
                    break;

                case 8:
                    System.out.println("Logging out...");
                    return;

                case 9:
                    reservations.manageReservation();
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
